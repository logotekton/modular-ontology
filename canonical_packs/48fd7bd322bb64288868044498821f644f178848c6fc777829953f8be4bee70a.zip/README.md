# Revit Model Inventory 03

Element detail shard with category, type, level, workset, and module links for model-state questions.

## Counts

- Nodes: 3000
- Edges: 12063
- Chunks: 3000
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
