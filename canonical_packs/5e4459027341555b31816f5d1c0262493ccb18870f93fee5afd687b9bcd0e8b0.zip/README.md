# 여주 모듈러 간부숙소 신축공사 내역서 온톨로지 팩

여주 모듈러 간부숙소 신축공사 내역서 온톨로지 팩은 엑셀 BOQ의 모듈 타입, 공종, 품목, 규격, 단위, 수량, 산식, BIM 참조, 단가와 금액 구조를 그래프로 정리한 BIM-to-BOQ 지식팩이다. 원본 계획서와 엑셀의 각 비어 있지 않은 행을 청크로 보존하고, 산출근거·공식·BIM 참조는 Evidence와 그래프 관계로 분리해 추적 가능하게 했다. 이 팩은 모듈별 공사비 질의, BIM 기반 산출 항목 탐색, 전체 품목집계 검증, Neo4j/LocalCrab 기반 BOQ 분석 실험에 사용할 수 있다.

## Ingest Entrypoints

- `manifest.json`
- `cloud/documents.jsonl`
- `cloud/chunks.jsonl`
- `graph/nodes.jsonl`
- `graph/edges.jsonl`

## Source Policy

The workbook itself is not copied into the ZIP because `.xlsx` is not an OpenCrab Data ZIP allowed extension. Instead, every non-empty source row is preserved as UTF-8 JSONL evidence with source sheet and row metadata.
