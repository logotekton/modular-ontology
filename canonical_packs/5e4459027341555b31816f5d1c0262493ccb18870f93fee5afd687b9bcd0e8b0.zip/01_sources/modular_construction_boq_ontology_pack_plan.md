# 모듈러 건축 공사 내역서 온톨로지 팩 구축 계획서

## 0. 팩 개요

```yaml
pack_id: modular_construction_boq_ontology_pack_yeoju_military_housing
name: 여주 모듈러 간부숙소 신축공사 내역서 온톨로지 팩
category: modular_construction_boq_cost_estimation
source_file: 260616_여주 모듈러 간부숙소 신축공사_내역서.xlsx
project_name: 여주 군관사 제작, 설치
primary_goal: 모듈러 건축 공사 내역서의 품목, 규격, 수량, 산식, 단가, 금액, 공종, 모듈 타입 간 관계를 구조화하여 BIM-to-Cost / BOQ-to-AI 질의응답이 가능한 온톨로지 팩을 구축한다.
status: planning
```

---

## 1. 팩의 목적

이 팩은 단순히 엑셀 내역서를 저장하는 것이 아니라, **모듈러 건축 공사의 공종·품목·규격·수량·산식·단가·금액·모듈 타입·BIM 산출근거를 AI가 해석 가능한 그래프 구조로 변환**하는 것을 목표로 한다.

```text
목표:
├─ 엑셀 내역서의 계층 구조를 보존한다.
├─ 모듈별 내역과 전체 품목 집계를 연결한다.
├─ 산출근거와 수량을 evidence로 분리한다.
├─ 공종별·모듈별·품목별 수량 질의를 가능하게 한다.
├─ BIM 데이터 기반 산식과 수동 산식을 구분한다.
├─ 단가/금액/합계 구조를 비용 온톨로지로 변환한다.
├─ 향후 Revit/IFC/BIM 객체와 연결 가능한 cost ontology를 만든다.
└─ AI가 “왜 이 수량이 나왔는가?”를 추적할 수 있게 한다.
```

---

## 2. 원본 엑셀 구조 분석

원본 파일은 총 **5개 시트**로 구성되어 있다.

| No | 시트명 | 행 수 | 열 수 | 성격 |
|---:|---|---:|---:|---|
| 1 | `건축_모듈내역` | 2,058 | 14 | 모듈 타입별 상세 내역서 |
| 2 | `건축_모듈산출근거` | 2,277 | 6 | 모듈 타입별 수량 산출근거 |
| 3 | `건축_공사산출근거` | 113 | 6 | 현장/공사 공통 산출근거 |
| 4 | `건축_품목집계(전체)` | 240 | 14 | 전체 품목 집계 |
| 5 | `건축_공사내역` | 119 | 14 | 모듈 외 공사 내역 |

---

## 3. 시트별 온톨로지화 방향

## 3.1 `건축_모듈내역`

### 성격

모듈 타입별로 품목, 규격, 단위, 수량, 재료비, 노무비, 경비, 합계를 정리한 상세 내역서다.

### 주요 컬럼 구조

| 컬럼 | 의미 |
|---|---|
| A | 코드 / 공종 |
| B | 품명 / 모듈 타입 / 구분 |
| C | 규격 |
| D | 단위 |
| E | 수량 |
| F-G | 재료비 단가 / 금액 |
| H-I | 노무비 단가 / 금액 |
| J-K | 경비 단가 / 금액 |
| L-M | 합계 단가 / 금액 |
| N | 비고 |

### 추출해야 할 핵심 구조

```text
ModuleEstimateSheet
├─ ModuleType
│   ├─ 1-01-M
│   ├─ 1-02-A
│   ├─ 1-03-A
│   ├─ ...
│   └─ 2-xx-A
│
├─ WorkCategory
│   ├─ 구조
│   ├─ 천장
│   ├─ 데크플레이트
│   ├─ 콘크리트
│   ├─ 바닥
│   ├─ 벽체
│   ├─ 창호
│   └─ 가구
│
└─ EstimateItem
    ├─ 품명
    ├─ 규격
    ├─ 단위
    ├─ 수량
    ├─ 재료비
    ├─ 노무비
    ├─ 경비
    └─ 합계
```

### 관찰된 공종별 항목 수

| 공종 | 항목 수 |
|---|---:|
| 구조 | 269 |
| 천장 | 182 |
| 데크플레이트 | 84 |
| 콘크리트 | 63 |
| 바닥 | 270 |
| 벽체 | 451 |
| 창호 | 412 |
| 가구 | 113 |

### 주요 단위 분포

| 단위 | 항목 수 |
|---|---:|
| ㎡ | 863 |
| 개소 | 429 |
| TON | 241 |
| m | 158 |
| 조 | 70 |
| ㎥ | 43 |
| EA | 24 |
| 매 | 16 |

---

## 3.2 `건축_모듈산출근거`

### 성격

모듈 타입별 수량이 어떤 산식으로 산출되었는지 설명하는 근거 시트다.  
특히 “BIM 데이터에 의한 면적 계산”, “BIM 데이터에 의한 길이 계산” 같은 표현이 포함되어 있어 **BIM-to-BOQ 연결 evidence**로 매우 중요하다.

### 주요 컬럼 구조

| 컬럼 | 의미 |
|---|---|
| A | 코드 / 공종 |
| B | 품명 |
| C | 규격 |
| D | 단위 |
| E | 산식 |
| F | 수량 |

### 추출해야 할 핵심 구조

```text
QuantityTakeoffEvidence
├─ ModuleType
├─ WorkCategory
├─ Item
├─ Specification
├─ Unit
├─ Formula
├─ Quantity
├─ FormulaSourceType
│   ├─ manual_formula
│   ├─ bim_area_based
│   ├─ bim_length_based
│   ├─ bim_count_based
│   └─ unit_weight_based
└─ ReferencedElement
    ├─ wall_type
    ├─ door_type
    ├─ window_type
    ├─ steel_section
    └─ material_layer
```

### 관찰된 공종별 항목 수

| 공종 | 항목 수 |
|---|---:|
| 구조 | 269 |
| 천장 | 166 |
| 데크플레이트 | 84 |
| 콘크리트 | 63 |
| 바닥 | 269 |
| 벽체 | 430 |
| 창호 | 42 |

### 산식 예시 유형

```text
구조:
((3.455*6))*49.894/1000
→ 부재 길이 × 단위중량 / 1000

콘크리트:
('36.85'<BIM 데이터에 의한 면적 계산>)*0.180
→ BIM 면적 × 두께

바닥:
('18.95'<BIM 데이터에 의한 면적 계산>)
→ BIM 면적 직접 사용

창호:
((((1.1+2.1)*2)<SD1>)*1)+...
→ 창호 둘레 × 개수
```

---

## 3.3 `건축_공사산출근거`

### 성격

모듈 내부가 아닌 현장 공사 또는 공통 공사의 산출근거를 담는다.

### 관찰된 주요 공종

| 공종 | 항목 수 |
|---|---:|
| 철근콘크리트공사 | 4 |
| 구조 | 12 |
| 철골공사 | 1 |
| 방수공사 | 1 |
| 지붕 | 7 |
| 창호및유리공사 | 2 |
| 타일및돌공사 | 4 |
| 수장공사 | 24 |
| 계단공사 | 4 |

### 온톨로지화 방향

```text
SiteWorkQuantityEvidence
├─ WorkCategory
├─ Item
├─ Specification
├─ Unit
├─ Formula
├─ Quantity
├─ SourceType
└─ BIMReference
```

이 시트는 모듈 타입이 아니라 **공사 공종 단위**로 묶어야 한다.

---

## 3.4 `건축_품목집계(전체)`

### 성격

모듈 내역과 공사 내역을 통합한 전체 품목 집계 시트다.  
동일 품명·규격·단위가 집계된 상태이므로, **중복 품목 정규화와 총량 검증의 기준 시트**로 사용한다.

### 관찰된 주요 공종

| 공종 | 항목 수 |
|---|---:|
| 구조 | 24 |
| 가구 | 10 |
| 계단공사 | 4 |
| 공통공사 | 4 |
| 금속공사 | 3 |
| 데크플레이트 | 4 |
| 바닥 | 23 |
| 방수공사 | 1 |
| 벽체 | 37 |
| 수장공사 | 26 |
| 지붕 | 9 |
| 창호 | 33 |
| 창호및유리공사 | 14 |
| 천장 | 13 |
| 철골공사 | 1 |
| 철근콘크리트공사 | 4 |
| 콘크리트 | 3 |
| 타일및돌공사 | 4 |

### 온톨로지화 방향

```text
AggregatedBOQItem
├─ WorkCategory
├─ ItemName
├─ Specification
├─ Unit
├─ TotalQuantity
├─ MaterialCost
├─ LaborCost
├─ ExpenseCost
├─ TotalCost
└─ AggregatedFrom
    ├─ ModuleEstimateItem
    └─ SiteWorkItem
```

이 시트는 전체 수량 합계의 “정답지” 역할을 하므로, 모듈별 상세 내역과 연결하여 검증해야 한다.

---

## 3.5 `건축_공사내역`

### 성격

모듈 외 공사, 공통 공사, 현장 설치성 공사 내역을 담는다.

### 관찰된 주요 공종

| 공종 | 항목 수 |
|---|---:|
| 공통공사 | 4 |
| 철근콘크리트공사 | 4 |
| 철골공사 | 1 |
| 방수공사 | 1 |
| 금속공사 | 3 |
| 지붕 | 9 |
| 창호및유리공사 | 14 |
| 타일및돌공사 | 4 |
| 수장공사 | 26 |
| 계단공사 | 4 |

### 온톨로지화 방향

```text
SiteWorkEstimateItem
├─ WorkCategory
├─ ItemName
├─ Specification
├─ Unit
├─ Quantity
├─ MaterialUnitPrice
├─ MaterialAmount
├─ LaborUnitPrice
├─ LaborAmount
├─ ExpenseUnitPrice
├─ ExpenseAmount
├─ TotalUnitPrice
└─ TotalAmount
```

---

## 4. 핵심 온톨로지 모델

## 4.1 Core Node Types

```text
Node Types
├─ Project
├─ EstimateWorkbook
├─ EstimateSheet
├─ ModuleType
├─ WorkCategory
├─ BOQItem
├─ EstimateItem
├─ AggregatedBOQItem
├─ SiteWorkItem
├─ QuantityTakeoffEvidence
├─ Formula
├─ FormulaTerm
├─ BIMReference
├─ Unit
├─ Material
├─ Specification
├─ CostComponent
├─ UnitPrice
├─ Amount
├─ Quantity
├─ QuantitySource
├─ ConstructionSystem
├─ BuildingElementType
├─ DoorWindowType
├─ SteelSection
├─ RoomOrSpace
├─ ValidationRule
└─ DataQualityIssue
```

---

## 4.2 Core Relation Types

```text
Relations
├─ HAS_SHEET
├─ HAS_MODULE_TYPE
├─ HAS_WORK_CATEGORY
├─ HAS_ESTIMATE_ITEM
├─ HAS_SITE_WORK_ITEM
├─ HAS_AGGREGATED_ITEM
├─ BELONGS_TO_PROJECT
├─ BELONGS_TO_MODULE
├─ BELONGS_TO_WORK_CATEGORY
├─ HAS_SPECIFICATION
├─ HAS_UNIT
├─ HAS_QUANTITY
├─ HAS_FORMULA
├─ HAS_COST_COMPONENT
├─ HAS_UNIT_PRICE
├─ HAS_AMOUNT
├─ CALCULATED_BY
├─ DERIVED_FROM_BIM
├─ REFERENCES_BIM_ELEMENT
├─ REFERENCES_DOOR_WINDOW_TYPE
├─ REFERENCES_STEEL_SECTION
├─ AGGREGATED_FROM
├─ SAME_AS_ITEM
├─ VALIDATED_BY
├─ HAS_DATA_QUALITY_ISSUE
└─ REQUIRES_REVIEW
```

---

## 5. OpenCrab 9 Spaces 설계

| Space | 본 팩에서의 의미 |
|---|---|
| `subject` | 프로젝트, 모듈 타입, 공종, 품목, BIM 객체, 산출 주체 |
| `resource` | 엑셀 파일, 시트, 행, 셀, 산식, 집계표 |
| `evidence` | 수량 산식, BIM 데이터 참조, 단가/금액 산정식, 엑셀 행 원문 |
| `concept` | 공종, 내역, 산출근거, 품목, 규격, 단위, 수량, 단가, 금액, 모듈 |
| `claim` | “이 품목의 수량은 해당 산식으로 산출되었다”, “이 항목은 BIM 면적 기반이다” |
| `community` | 모듈 내역군, 공사 내역군, 구조 품목군, 창호 품목군, 수장 공사군 |
| `outcome` | 전체 내역서, 모듈별 내역, 공종별 집계, BIM 연계 내역, 검증 결과 |
| `lever` | 수량, 단가, 단위, 산식, BIM 면적, BIM 길이, 단위중량, 모듈 개수 |
| `policy` | 수량 검증 규칙, 단위 정규화 규칙, 품목 병합 규칙, 산식 파싱 규칙 |

---

## 6. 데이터 정규화 규칙

## 6.1 모듈 타입 인식 규칙

모듈 타입은 시트 내 구분 행에서 추출한다.

```text
패턴 예시:
1-01-M
1-02-A
1-03-A
1-05-ST
2-01-A
2-05-ST
```

### 정규화 필드

```json
{
  "module_type_id": "1-01-M",
  "floor_code": "1",
  "sequence": "01",
  "module_variant": "M"
}
```

---

## 6.2 공종 인식 규칙

A열의 코드 값 또는 섹션 행을 기준으로 공종을 인식한다.

```text
모듈 내 공종:
├─ 구조
├─ 천장
├─ 데크플레이트
├─ 콘크리트
├─ 바닥
├─ 벽체
├─ 창호
└─ 가구

공사 공종:
├─ 공통공사
├─ 철근콘크리트공사
├─ 철골공사
├─ 방수공사
├─ 금속공사
├─ 지붕
├─ 창호및유리공사
├─ 타일및돌공사
├─ 수장공사
└─ 계단공사
```

---

## 6.3 품목 정규화 규칙

동일 품목 판단은 다음 키로 한다.

```text
ItemIdentityKey =
품명 + 규격 + 단위 + 공종
```

단, 창호와 벽체 유형은 품명이 부호 역할을 하므로 별도 타입으로 분리한다.

```text
창호:
PD1, SD1, SD2, AW1, AW5, SSD1 ...

벽체:
D1, D2, D3, D4, D5 ...

구조:
H 200x200x8x12
H 300x150x6.5x9
C 125x65x6x8
L 50x50x4
```

---

## 6.4 단위 정규화 규칙

```text
㎡  → square_meter
㎥  → cubic_meter
m   → meter
TON → metric_ton
EA  → each
개소 → location_count
조  → set
매  → sheet
```

---

## 6.5 산식 유형 분류 규칙

산식 문자열을 파싱하여 다음 source type으로 분류한다.

```text
FormulaSourceType
├─ manual_formula
│   └─ 일반 산술식
│
├─ bim_area_based
│   └─ "<BIM 데이터에 의한 면적 계산>" 포함
│
├─ bim_length_based
│   └─ "<BIM 데이터에 의한 길이 계산>" 포함
│
├─ bim_count_based
│   └─ 개수, 창호 부호, 모듈 반복 참조
│
├─ unit_weight_based
│   └─ 형강 길이 × 단위중량 / 1000
│
├─ opening_deduction_based
│   └─ 벽체 면적 - 창호/문 면적 공제
│
└─ perimeter_based
    └─ 창호 둘레 × 개수
```

---

## 7. 비용 온톨로지 구조

내역서의 비용 구조는 다음처럼 분해한다.

```text
CostStructure
├─ MaterialCost
│   ├─ UnitPrice
│   └─ Amount
│
├─ LaborCost
│   ├─ UnitPrice
│   └─ Amount
│
├─ ExpenseCost
│   ├─ UnitPrice
│   └─ Amount
│
└─ TotalCost
    ├─ UnitPrice
    └─ Amount
```

### 금액 산정 관계

```text
Quantity × MaterialUnitPrice → MaterialAmount
Quantity × LaborUnitPrice → LaborAmount
Quantity × ExpenseUnitPrice → ExpenseAmount
MaterialAmount + LaborAmount + ExpenseAmount → TotalAmount
```

### 엑셀 수식 보존

원본 엑셀에는 다음과 같은 수식 구조가 반복된다.

```text
=TRUNC(E6*F6)
=TRUNC(E6*H6)
```

따라서 팩에는 값뿐 아니라 **엑셀 수식 자체**도 evidence로 보존한다.

---

## 8. BIM-to-BOQ 연결 설계

이 내역서의 중요한 특징은 산출근거에 BIM 데이터 참조가 포함되어 있다는 점이다.

```text
예시:
('36.85'<BIM 데이터에 의한 면적 계산>)*0.180
('9.79'<BIM 데이터에 의한 길이 계산>)
(809.137<BIM 데이터에 의한 면적 계산>)
```

이 구조는 다음과 같이 온톨로지화한다.

```text
BIMReference
├─ source_type: BIM 데이터
├─ measurement_type
│   ├─ area
│   ├─ length
│   ├─ volume
│   └─ count
├─ measurement_value
├─ measurement_unit
├─ referenced_element_type
└─ used_in_formula
```

### BIM 연결 확장 방향

```text
현재:
엑셀 산식 안의 BIM 데이터 참조 문자열

향후:
Revit Room / Wall / Floor / Door / Window / Structural Framing 객체와 연결

최종:
BIM Object → Quantity Takeoff → BOQ Item → Cost Item → Proposal / Estimate
```

---

## 9. 품질 검증 규칙

## 9.1 수량 검증

```text
검증 1:
모듈별 상세 내역 수량 합계
= 전체 품목집계 수량

검증 2:
산출근거 수량
= 내역서 수량

검증 3:
BIM 산식 계산 결과
= 기입 수량

검증 4:
단위중량 기반 구조 물량
= 길이 × 단위중량 / 1000
```

---

## 9.2 금액 검증

```text
검증 1:
재료비 금액 = TRUNC(수량 × 재료비 단가)

검증 2:
노무비 금액 = TRUNC(수량 × 노무비 단가)

검증 3:
경비 금액 = TRUNC(수량 × 경비 단가)

검증 4:
합계 금액 = 재료비 금액 + 노무비 금액 + 경비 금액
```

---

## 9.3 데이터 품질 이슈 감지

```text
DataQualityIssue
├─ missing_unit
├─ missing_quantity
├─ missing_specification
├─ formula_quantity_mismatch
├─ aggregated_quantity_mismatch
├─ invalid_unit
├─ duplicated_item_key
├─ ambiguous_work_category
├─ unparsed_formula
└─ manual_review_required
```

---

## 10. 샘플 노드 구조

## 10.1 ModuleType Node

```json
{
  "node_type": "ModuleType",
  "id": "module_type_1_01_M",
  "name": "1-01-M",
  "floor_code": "1",
  "sequence": "01",
  "variant": "M",
  "source_sheet": "건축_모듈내역"
}
```

---

## 10.2 EstimateItem Node

```json
{
  "node_type": "EstimateItem",
  "id": "estimate_item_1_01_M_structure_h200x200",
  "module_type": "1-01-M",
  "work_category": "구조",
  "item_name": "용접구조용 압연강재",
  "specification": "H 200x200x8x12, SM355",
  "unit": "TON",
  "quantity": 1.034,
  "source_sheet": "건축_모듈내역",
  "source_row": 6
}
```

---

## 10.3 QuantityTakeoffEvidence Node

```json
{
  "node_type": "QuantityTakeoffEvidence",
  "id": "qto_evidence_1_01_M_structure_h200x200",
  "module_type": "1-01-M",
  "work_category": "구조",
  "item_name": "용접구조용 압연강재",
  "formula": "((3.455*6))*49.894/1000",
  "formula_source_type": "unit_weight_based",
  "quantity": 1.034,
  "unit": "TON",
  "source_sheet": "건축_모듈산출근거"
}
```

---

## 10.4 BIMReference Node

```json
{
  "node_type": "BIMReference",
  "id": "bim_ref_floor_area_36_85",
  "measurement_type": "area",
  "measurement_value": 36.85,
  "measurement_unit": "square_meter",
  "source_expression": "('36.85'<BIM 데이터에 의한 면적 계산>)",
  "used_in_formula": "('36.85'<BIM 데이터에 의한 면적 계산>)*0.180"
}
```

---

## 11. 샘플 그래프 관계

```text
Project("여주 군관사 제작, 설치")
  └─ HAS_SHEET → EstimateSheet("건축_모듈내역")

EstimateSheet("건축_모듈내역")
  └─ HAS_MODULE_TYPE → ModuleType("1-01-M")

ModuleType("1-01-M")
  └─ HAS_ESTIMATE_ITEM → EstimateItem("용접구조용 압연강재 / H 200x200x8x12")

EstimateItem
  ├─ BELONGS_TO_WORK_CATEGORY → WorkCategory("구조")
  ├─ HAS_UNIT → Unit("TON")
  ├─ HAS_QUANTITY → Quantity(1.034)
  └─ CALCULATED_BY → QuantityTakeoffEvidence("((3.455*6))*49.894/1000")

QuantityTakeoffEvidence
  └─ HAS_FORMULA → Formula("((3.455*6))*49.894/1000")

Formula
  └─ HAS_FORMULA_SOURCE_TYPE → unit_weight_based
```

---

## 12. 대표 질의 시나리오

이 팩이 구축되면 다음 질의에 답할 수 있어야 한다.

```text
1. 1-01-M 모듈의 구조 물량을 보여줘.
2. 1층 모듈과 2층 모듈의 벽체 물량 차이를 비교해줘.
3. 전체 창호 수량을 창호 타입별로 집계해줘.
4. H 200x200x8x12 강재가 어떤 모듈에 얼마나 들어가는지 알려줘.
5. BIM 데이터 기반으로 산출된 항목만 찾아줘.
6. 수동 산식과 BIM 산식이 섞인 항목을 분리해줘.
7. 전체 품목집계와 모듈별 상세 내역의 수량이 일치하는지 검증해줘.
8. 단위가 TON인 모든 구조 품목을 집계해줘.
9. 벽체 D1, D3, D4 유형별 총 면적을 알려줘.
10. 공사 내역 중 현장 공사 성격의 항목만 분리해줘.
11. 창호 주위 코킹 수량 산식이 어떤 창호 타입을 참조하는지 분석해줘.
12. 콘크리트 수량이 어떤 BIM 면적과 두께로 산출되었는지 설명해줘.
```

---

## 13. 구축 파이프라인

## Phase 1. Workbook Profiling

```text
- 시트 목록 추출
- 시트별 행/열 구조 파악
- 헤더 행 인식
- 병합 셀/섹션 행/빈 행 처리
- 모듈 타입 블록 위치 추출
```

## Phase 2. Row Classification

```text
행 분류:
├─ title_row
├─ project_info_row
├─ header_row
├─ subheader_row
├─ module_section_row
├─ work_category_section_row
├─ estimate_item_row
├─ quantity_evidence_row
├─ subtotal_row
├─ blank_row
└─ note_row
```

## Phase 3. Entity Extraction

```text
추출 엔티티:
├─ Project
├─ Sheet
├─ ModuleType
├─ WorkCategory
├─ ItemName
├─ Specification
├─ Unit
├─ Quantity
├─ Formula
├─ CostComponent
└─ BIMReference
```

## Phase 4. Normalization

```text
- 단위 표준화
- 품목명 정규화
- 규격 문자열 표준화
- 모듈 타입 코드 분해
- 공종명 표준화
- 창호/벽체/구조 부재 코드 분리
```

## Phase 5. Formula Parsing

```text
- 일반 산식 파싱
- BIM 데이터 참조 추출
- 창호/문 부호 참조 추출
- 단위중량 기반 구조 산식 추출
- 면적 공제 항목 추출
- 산식 결과와 수량 비교
```

## Phase 6. Graph Construction

```text
- nodes.json 생성
- edges.json 생성
- evidence.json 생성
- formula_index.json 생성
- item_identity_index.json 생성
- bim_reference_index.json 생성
```

## Phase 7. Validation

```text
- 내역 수량 vs 산출근거 수량 비교
- 상세 내역 vs 전체 품목집계 비교
- 금액 수식 검증
- 단위 누락 검토
- 중복 품목 검토
- 미파싱 산식 검토
```

## Phase 8. Pack Export

```text
- README.md
- pack.yaml
- schema/*.json
- graph/nodes.json
- graph/edges.json
- evidence/*.json
- validation/report.md
- examples/sample_queries.md
```

---

## 14. 권장 폴더 구조

```text
modular_construction_boq_ontology_pack_yeoju/
├─ README.md
├─ pack.yaml
│
├─ 01_source/
│   ├─ original_workbook.xlsx
│   ├─ sheet_profile.json
│   └─ workbook_metadata.json
│
├─ 02_schema/
│   ├─ project.schema.json
│   ├─ module_type.schema.json
│   ├─ work_category.schema.json
│   ├─ boq_item.schema.json
│   ├─ estimate_item.schema.json
│   ├─ quantity_takeoff_evidence.schema.json
│   ├─ formula.schema.json
│   ├─ bim_reference.schema.json
│   ├─ cost_component.schema.json
│   └─ validation_rule.schema.json
│
├─ 03_extracted/
│   ├─ module_estimate_items.json
│   ├─ module_quantity_evidence.json
│   ├─ site_work_items.json
│   ├─ site_work_quantity_evidence.json
│   ├─ aggregated_boq_items.json
│   └─ normalized_units.json
│
├─ 04_graph/
│   ├─ nodes.json
│   ├─ edges.json
│   ├─ graph_summary.json
│   └─ cypher_import.cypher
│
├─ 05_indexes/
│   ├─ item_identity_index.json
│   ├─ module_type_index.json
│   ├─ work_category_index.json
│   ├─ formula_index.json
│   ├─ bim_reference_index.json
│   └─ door_window_type_index.json
│
├─ 06_validation/
│   ├─ quantity_validation_report.md
│   ├─ cost_validation_report.md
│   ├─ aggregation_validation_report.md
│   └─ data_quality_issues.json
│
└─ 07_examples/
    ├─ sample_queries.md
    ├─ sample_answers.md
    └─ boq_to_bim_use_cases.md
```

---

## 15. pack.yaml 초안

```yaml
id: modular_construction_boq_ontology_pack_yeoju_military_housing
name: 여주 모듈러 간부숙소 신축공사 내역서 온톨로지 팩
version: 0.1.0
category: modular_construction_boq_cost_estimation
source_type: excel_workbook
source_file: 260616_여주 모듈러 간부숙소 신축공사_내역서.xlsx

project:
  name: 여주 군관사 제작, 설치
  type: modular_military_housing
  domain: architecture_modular_construction

scope:
  included:
    - module_estimate
    - module_quantity_takeoff
    - site_work_estimate
    - site_work_quantity_takeoff
    - aggregated_boq
    - cost_components
    - formula_evidence
    - bim_reference_evidence
  excluded:
    - mechanical_estimate
    - electrical_estimate
    - plumbing_estimate
    - schedule
    - contract_terms

core_spaces:
  - subject
  - resource
  - evidence
  - concept
  - claim
  - community
  - outcome
  - lever
  - policy

core_node_types:
  - Project
  - EstimateWorkbook
  - EstimateSheet
  - ModuleType
  - WorkCategory
  - BOQItem
  - EstimateItem
  - AggregatedBOQItem
  - SiteWorkItem
  - QuantityTakeoffEvidence
  - Formula
  - BIMReference
  - Unit
  - Specification
  - CostComponent
  - ValidationRule
  - DataQualityIssue

validation_policy:
  preserve_excel_formula: true
  preserve_source_cell_reference: true
  validate_quantity_against_formula: true
  validate_aggregate_quantity: true
  validate_cost_formula: true
  detect_bim_reference: true
  detect_unparsed_formula: true
```

---

## 16. 향후 확장 가능성

## 16.1 BIM 객체 연결

```text
현재:
Excel BOQ Item

확장:
Revit Element
├─ Category
├─ Family
├─ Type
├─ Parameter
├─ Quantity
└─ Material

연결:
Revit Element → BIM Quantity → BOQ Item → Cost Item
```

---

## 16.2 모듈러 생산/MES 연결

```text
BOQ Item
├─ Material Requirement
├─ Procurement Item
├─ Factory Work Package
├─ Module Assembly Step
├─ Welding / Framing Task
├─ Finishing Task
└─ Installation Task
```

---

## 16.3 AI 질의응답 기능

```text
사용자 질문:
“1층 모듈과 2층 모듈의 구조 물량 차이가 왜 나?”

AI 응답 근거:
├─ 모듈 타입별 구조 품목 수량
├─ 산출근거 산식
├─ 부재 규격 차이
├─ 창호/개구부 공제 차이
├─ BIM 면적/길이 차이
└─ 전체 품목집계 검증
```

---

## 17. 최종 결론

이 엑셀 내역서는 온톨로지 팩으로 만들기에 적합하다. 특히 다음 세 가지 이유가 크다.

```text
1. 모듈별 상세 내역과 전체 품목집계가 분리되어 있다.
2. 내역서와 산출근거 시트가 별도로 존재한다.
3. 산식 안에 BIM 데이터 기반 수량 참조가 포함되어 있다.
```

따라서 이 팩은 단순한 공사비 내역서 팩이 아니라, **모듈러 건축 BIM-to-BOQ 온톨로지 팩**으로 설계하는 것이 적절하다.

최종 정의는 다음과 같다.

> **여주 모듈러 간부숙소 신축공사 내역서 온톨로지 팩은 모듈러 건축 공사의 모듈 타입, 공종, 품목, 규격, 단위, 수량, 산식, BIM 참조, 단가, 금액, 전체 집계를 구조화하여 AI가 공사비 내역과 수량 산출근거를 질의·검증·분석할 수 있도록 하는 BIM-to-BOQ 지식팩이다.**
