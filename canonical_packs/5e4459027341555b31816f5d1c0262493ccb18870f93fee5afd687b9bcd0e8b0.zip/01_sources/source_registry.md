# Source Registry

- Plan: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\99.팩테스트\modular_construction_boq_ontology_pack_plan.md`
- Workbook: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\99.팩테스트\260616_여주 모듈러 간부숙소 신축공사_내역서.xlsx`

Every non-empty workbook row is preserved as one source chunk in `cloud/chunks.jsonl`.
