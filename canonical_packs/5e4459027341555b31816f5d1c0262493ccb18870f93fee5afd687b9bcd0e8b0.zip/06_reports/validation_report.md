# Validation Report

## Internal Quality Gate
- PASS `nodes_at_least_500`
- PASS `edges_under_15000`
- PASS `no_duplicate_node_ids`
- PASS `no_duplicate_edges`
- PASS `no_missing_edge_endpoints`
- PASS `no_duplicate_document_urls`
- PASS `no_duplicate_chunk_ids`
- PASS `every_chunk_indexed`
- PASS `every_chunk_has_evidence_index`
- PASS `source_chunks_nonempty`
- PASS `documents_nonempty`
- PASS `localcrab_dry_run_passed`
- PASS `no_unintended_orphan_nodes`

## LocalCrab / OpenCrab Dry Run
- status: pass
- method: opencrab.mcp.tools.harness_promotion_apply
- dry_run_nodes_validated: 6853
- dry_run_errors: 0

## ZIP Validation
- passed: True
- nodes: 5853
- edges: 14744
- PASS `nodes_at_least_min`
- PASS `edges_under_max`
- PASS `edge_endpoints_exist`
- PASS `no_duplicate_node_ids`
- PASS `no_duplicate_edges`
- PASS `zip_exists`
- PASS `zip_entry_limit`
- PASS `zip_extension_allowlist`
- PASS `zip_hidden_paths_excluded`
- PASS `zip_file_size_limit`
- PASS `zip_jsonl_valid`
- PASS `readable_document_exists`
- PASS `cloud_pack_required_files`
- PASS `graph_pack_required_files`
- PASS `graph_node_ids_present`
- PASS `graph_edge_endpoints_present`

## Neo4j Passive Import
- status: fail
- uri: bolt://localhost:7687
- database_attempted: neo4j
- nodes_written: 0
- edges_written: 0
- verify_nodes: None
- verify_edges: None
- error: ServiceUnavailable: Couldn't connect to localhost:7687 (resolved to ('127.0.0.1:7687', '[::1]:7687')):
Failed to establish connection to ResolvedIPv4Address(('127.0.0.1', 7687)) (reason [WinError 10061] 대상 컴퓨터에서 연결을 거부했으므로 연결하지 못했습니다)
Failed to establish connection to ResolvedIPv6Address(('::1', 7687, 0, 0)) (reason [WinError 10061] 대상 컴퓨터에서 연결을 거부했으므로 연결하지 못했습니다)
