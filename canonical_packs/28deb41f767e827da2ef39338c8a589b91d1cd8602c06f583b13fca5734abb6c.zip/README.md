# Drawing Representation Primary Links 04

Drawing Representation Primary Links 04은 Phase 2 최종 실행의 확정 및 고신뢰 표현 링크 증거를 문서키 범위의 결정적 ID로 담은 SHIP 추가 팩입니다. 모든 노드와 관계는 원본 JSONL 행을 evidence_refs로 추적하며, 확정·고신뢰 결과와 검토 후보를 검색 정책 필드로 구분합니다. 기존 0.8.4 SHIP 노드를 복제하지 않고 요소·시트·뷰 ID에 결합하므로 도면 표현 위치 질의와 QA 검토에 함께 사용할 수 있습니다.

## Counts

- Nodes: 3765
- Edges: 11295
- Chunks: 3765
- External SHIP endpoints: 836

## Confidence policy

- `primary_searchable=true`: confirmed/high-confidence result.
- `review_required=true`: review/candidate result; not a primary auto-confirmed match.
- QA evidence remains searchable as QA and never promotes a candidate match.
