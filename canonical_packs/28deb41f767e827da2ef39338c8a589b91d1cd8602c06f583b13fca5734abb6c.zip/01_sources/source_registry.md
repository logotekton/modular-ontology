# Source Registry

- Phase 2 source run: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\analysis\drawing_representation_port\runs\20260710-1420-p23`
- Read-only SHIP suite: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\온톨로지팩\여주\건축\revit-yeoju-architecture-acadsharp-schema-0_8_4-20260710_092149-rebuild-20260710_102852`
- Document key: `여주모듈러간부숙소신축공사_ythongMPXL7-ce7740d4af12054e`
- Source schema: `0.8.4`

## Files

- `drawing_phase2_element_representation_links.jsonl`: 132700815 bytes, sha256 `8ac3332368c2cfac6934ae5bf3286618d0ad6f3ddbf8eb9cfeacf86b96aeacae`
- `drawing_level_module_sidecar.jsonl`: 10038764 bytes, sha256 `b5d9cf26081c9305200d14a54e5e72b8ff73e34cbad47a9fba42cd907b3876dd`
- `phase2_metrics.json`: 3316 bytes, sha256 `9ce5f714fd828cca09607f2b81bf7f585e7d438571d007345dc5787d418d6c7b`
