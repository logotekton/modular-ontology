# Validation Report

## Quality Gate
- PASS `nodes_nonempty`
- PASS `edges_nonempty`
- PASS `no_duplicate_node_ids`
- PASS `no_duplicate_edges`
- PASS `no_missing_edge_endpoints`
- PASS `chunks_nonempty`
- PASS `chunks_have_content`
- PASS `source_records_present`
- PASS `parse_success_rate_at_least_90_percent`
- PASS `requirement_evidence_linked`
- PASS `localcrab_internal_dry_run_passed`
- PASS `zip_validation_passed`
- PASS `parse_failures_recorded`
- PASS `all_passed`

## Parse Status
- cached: 14

## LocalCrab/OpenCrab Dry Run
- status: pass
- method: internal_opencrab_compatibility_dry_run

## ZIP Validation
- passed: True
- PASS `nodes_at_least_min`
- PASS `edges_under_max`
- PASS `edge_endpoints_exist`
- PASS `no_duplicate_node_ids`
- PASS `no_duplicate_edges`
- PASS `zip_exists`
- PASS `zip_entry_limit`
- PASS `zip_extension_allowlist`
- PASS `zip_hidden_paths_excluded`
- PASS `zip_file_size_limit`
- PASS `zip_jsonl_valid`
- PASS `readable_document_exists`
- PASS `cloud_pack_required_files`
- PASS `graph_pack_required_files`
- PASS `graph_node_ids_present`
- PASS `graph_edge_endpoints_present`
