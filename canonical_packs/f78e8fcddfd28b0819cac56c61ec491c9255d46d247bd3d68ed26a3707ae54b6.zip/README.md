# Revit Project MCP Bundle

Super-index pack that tells MCP which generated Revit packs and existing specification/law packs should be loaded together for project review.

## Counts

- Nodes: 157
- Edges: 156
- Chunks: 7
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
