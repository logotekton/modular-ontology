# Source Registry

- Revit export directory: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
- Revit schema version: `0.8.4`
- Exported at: `2026-07-10T09:21:49.3733692+09:00`

## Files
- `drawing_entities.jsonl`: 322092832 bytes
- `drawing_entity_context.jsonl`: 402411923 bytes
