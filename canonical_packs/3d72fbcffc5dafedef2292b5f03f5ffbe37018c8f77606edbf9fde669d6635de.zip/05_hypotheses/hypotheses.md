# Hypotheses

- Candidate spec and law links are review targets, not automatic pass/fail decisions.
