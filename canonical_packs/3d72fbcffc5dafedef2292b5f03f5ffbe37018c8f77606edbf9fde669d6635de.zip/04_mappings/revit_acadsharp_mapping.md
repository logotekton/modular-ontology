# Revit JSONL + ACadSharp DXF Mapping

- LocalCrab spaces are kept as resource, evidence, concept, and claim.
- BIM semantics are preserved in node_type, layer, and properties.bimgraph_node_kind.
- DXF raw record space is stored as properties.dxf_space; ontology node space remains evidence.
- External specification and law packs are referenced through internal reference nodes.
