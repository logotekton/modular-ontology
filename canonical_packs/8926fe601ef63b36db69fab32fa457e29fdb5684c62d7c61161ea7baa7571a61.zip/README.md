# 대한민국 건축 법규 (공동주택·기숙사·모듈러) - Building Code

opencrab-cloud-pack-v1 · pack_id: krlaw_building_code_20260707a · v0.2.0 (law.go.kr 원문 수록판)

## 출처
모든 조문(36건)·별표(7건)의 chunk 본문은 국가법령정보센터(law.go.kr)에서 2026-07-07 수집한 원문이다.
- 조문: 한글 법령주소(law.go.kr/법령/<법령명>/<조문>) → 본문 프레임에서 표(이미지 alt 텍스트) 포함 추출
- 별표: 별표 뷰어에서 공식 PDF를 내려받아 텍스트 추출 (승강기 별표1의2, 주차장 별표1,
  소방시설 별표4(2025.11.25 개정), 편의시설 별표1·별표2, 건축물 용도 별표1, 에너지 열관류율 별표1)
- 각 조문 노드 properties.source_url 에 원문 링크, lsi_seq 에 법령 버전 시퀀스 기록

## 구조
- law(10) → LAW_HAS_ARTICLE → law_article(조문+별표 44) → ARTICLE_DEFINES_REQUIREMENT → law_requirement(28)
- law_requirement → REQUIREMENT_APPLIES_TO_CATEGORY → 여주 BIM 팩 카테고리 노드
- law_requirement → REQUIREMENT_EVIDENCED_BY_SHEET → 여주 도면 시트 노드
- 위임 체계: ARTICLE_DELEGATES_TO (법 → 시행령 → 규칙 → 별표)

## 주의
모든 조문·별표 원문은 국가법령정보센터(law.go.kr)에서 2026-07-07 수집하여 수록함(조문 내 개정일 표기는 원문 그대로). 이후 개정 여부는 law.go.kr에서 확인.
