# Revit Project References

Project, export run, source file, category, level, grid, workset, family, type, material, and module reference graph.

## Counts

- Nodes: 4866
- Edges: 5240
- Chunks: 4866
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
