# ACadSharp DXF Layer Aggregates

DXF file and layer aggregate evidence. LINE, LWPOLYLINE, POLYLINE, and other low-information geometry are represented here by counts and context.

## Counts

- Nodes: 850
- Edges: 850
- Chunks: 753
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
