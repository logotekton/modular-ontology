# Revit Drawing Evidence

Sheet, view, viewport, schedule, schedule cell, annotation, and DXF drawing file references from the Revit export.

## Counts

- Nodes: 1024
- Edges: 181
- Chunks: 1024
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
