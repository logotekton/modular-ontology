# Source Registry

- Revit export directory: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
- Revit schema version: `0.8.4`
- Exported at: `2026-07-10T09:21:49.3733692+09:00`

## Files
- `sheets.jsonl`: 1521164 bytes
- `titleblocks.jsonl`: 907638 bytes
- `views.jsonl`: 1070538 bytes
- `viewports.jsonl`: 307512 bytes
- `schedules.jsonl`: 122220 bytes
- `schedule_cells.jsonl`: 255975 bytes
- `annotations.jsonl`: 18577473 bytes
- `sheet_dxfs.jsonl`: 146963 bytes
- `view_dxfs.jsonl`: 24653 bytes
- `sheet_pdfs.jsonl`: 89828 bytes
- `dxf_export_diagnostics.jsonl`: 2462 bytes
- `export_diagnostics.jsonl`: 21333 bytes
