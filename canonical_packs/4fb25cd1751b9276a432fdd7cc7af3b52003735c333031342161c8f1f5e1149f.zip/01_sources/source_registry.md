# Source Registry

- Phase 2 source run: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\analysis\drawing_representation_port\runs\20260710-1420-p23`
- Read-only SHIP suite: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\온톨로지팩\여주\건축\revit-yeoju-architecture-acadsharp-schema-0_8_4-20260710_092149-rebuild-20260710_102852`
- Document key: `여주모듈러간부숙소신축공사_ythongMPXL7-ce7740d4af12054e`
- Source schema: `0.8.4`

## Files

- `drawing_phase2_remaining_revit_elements.jsonl`: 3693511 bytes, sha256 `f59826915122e91d9c2beaf4152cbb65393c5c0b7217becebac0bb3a22116065`
- `drawing_stage45_matching_exempt_revit_elements.jsonl`: 682109 bytes, sha256 `66f30594460d8448a0e78206e7cccaf31db933ca59ce884400b944c0e11a37b3`
- `drawing_stage45_semantic_only_revit_elements.jsonl`: 1036464 bytes, sha256 `ea37de989c548abd9f6ec7f4fc79036dff49f362249b1c18c5f54079804e2f5e`
- `drawing_level_module_sidecar.jsonl`: 10038764 bytes, sha256 `b5d9cf26081c9305200d14a54e5e72b8ff73e34cbad47a9fba42cd907b3876dd`
- `phase2_metrics.json`: 3316 bytes, sha256 `9ce5f714fd828cca09607f2b81bf7f585e7d438571d007345dc5787d418d6c7b`
