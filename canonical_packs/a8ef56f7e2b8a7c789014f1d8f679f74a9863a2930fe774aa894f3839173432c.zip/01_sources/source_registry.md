# Source Registry

- pack_id: `spec_architecture_41_kds_41_20_pack`
- source_plan: `D:\02.AI 코딩\Opencrab test\시방서 팩\construction_specification_domain_pack_plan_v2.md`
- source_record_count: 2

원본 HWP는 ZIP에 포함하지 않는다. 원본 경로, SHA-256, Kordoc 추출 상태와 Evidence chunk 참조만 기록한다.
