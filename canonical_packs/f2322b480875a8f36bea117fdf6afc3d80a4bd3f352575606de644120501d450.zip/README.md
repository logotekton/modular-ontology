﻿# 시방서 전체 카탈로그

시방서 전체 카탈로그은 전체 HWP 시방서·설계기준 코퍼스의 분야 분류, 원본 경로, 해시, 중복 상태를 다루는 LocalCrab/OpenCrab Cloud Pack이다. 원본 HWP는 포함하지 않고 모든 대표 원본의 경로와 SHA-256, 분야 코드, shard 키를 Evidence chunk와 source registry로 보존한다. 이 팩은 분야별 팩을 찾는 루트 색인과 IFC 브리지의 기준 문서 탐색 출발점으로 사용할 수 있다.

## Evidence Policy

Kordoc으로 추출된 원문 chunk를 Evidence로 사용하며, 원본 HWP는 경로와 해시로만 추적한다. Requirement와 IFC 매핑 후보는 chunk 근거가 있을 때만 생성한다.
