# Revit Model Inventory 06

Element detail shard with category, type, level, workset, and module links for model-state questions.

## Counts

- Nodes: 1861
- Edges: 8434
- Chunks: 1861
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
