# Source Registry

- IFC source: `ifc_unified_evidence_pack_yeoju_military_housing_v6`
- referenced spec packs: 103

이 팩은 원문 시방서 내용을 복제하지 않고, 기존 시방서 팩의 requirement_id/chunk_id를 참조한다.
