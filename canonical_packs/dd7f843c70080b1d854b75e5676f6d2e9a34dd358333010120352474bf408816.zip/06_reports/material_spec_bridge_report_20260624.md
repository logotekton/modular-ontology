# 재료-시방서 브리지 팩 생성 보고서

- 생성일: 2026-06-24T06:55:27.558261+00:00
- IFC v6 재료 수: 128
- 표현된 재료 수: 128
- 후보가 있는 재료: 124
- 후보가 없는 재료: 4
- 선택된 시방서 팩: 73
- 선택된 Requirement: 478
- 후보 연결: 2480
- 노드/엣지/청크: 3843 / 27328 / 129
- 품질 게이트: PASS

## 원칙

- 기존 시방서 원문은 복제하지 않고 `source_pack_id`, `requirement_id`, `chunk_id`로 참조한다.
- 자동 적합/부적합 판정은 생성하지 않는다.
- 재료별 간단한 시방서 검토자료 생성을 위한 후보와 근거만 제공한다.

## 후보가 없는 재료
- <Unnamed> / object_count=1412 / status=UNCLASSIFIED_MATERIAL_NEEDS_REVIEW
- #Hidden / object_count=2 / status=UNCLASSIFIED_MATERIAL_NEEDS_REVIEW
- #SST / object_count=1 / status=UNCLASSIFIED_MATERIAL_NEEDS_REVIEW
- 기본 벽:DW6-MDF / object_count=1 / status=UNCLASSIFIED_MATERIAL_NEEDS_REVIEW
