# 재료-시방서 브리지 팩

IFC v6에서 추출한 재료 128개를 기존 시방서 팩의 Requirement/Chunk 후보와 연결하는 참조 브리지 팩이다. 자동 적합/부적합 판정은 하지 않고, 재료별 간단한 시방서 검토자료 생성을 위한 후보 조항과 근거 ID를 제공한다.

## 사용법

1. IFC v6 팩에서 재료명을 찾는다.
2. 이 브리지 팩의 `IFCMaterialReference` 또는 `material_index.json`에서 재료를 조회한다.
3. `MaterialSpecCandidate`가 참조하는 `source_pack_id`, `requirement_id`, `chunk_id`를 따라 기존 시방서 팩의 원문을 조회한다.
4. 이 팩은 자동 PASS/FAIL을 생성하지 않는다. 간단한 시방서 검토자료 생성을 위한 후보 연결만 제공한다.
