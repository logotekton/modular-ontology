﻿# 특수건축공사 시방서(KCS 41 70)

특수건축공사 시방서(KCS 41 70)은 건축 분야 중 `KCS_41_70` 세부분야의 KDS/KCS/전문시방서 원문 조항를 다루는 LocalCrab/OpenCrab Cloud Pack이다. 원본 HWP를 Kordoc Markdown으로 추출하고, 문서·chunk·Requirement 노드를 모두 원문 evidence_ref로 추적한다. 이 팩은 분야별 기준 검색과 IFC 객체/재료/치수 검토 후보 생성에 사용할 수 있다.

## Evidence Policy

Kordoc으로 추출된 원문 chunk를 Evidence로 사용하며, 원본 HWP는 경로와 해시로만 추적한다. Requirement와 IFC 매핑 후보는 chunk 근거가 있을 때만 생성한다.
