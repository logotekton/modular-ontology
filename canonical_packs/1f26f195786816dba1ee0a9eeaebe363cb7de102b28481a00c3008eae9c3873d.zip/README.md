# Revit Model Inventory Aggregates

Precomputed category, family, type, level, and module aggregates for fast model inventory answers.

## Counts

- Nodes: 1992
- Edges: 310
- Chunks: 1992
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
