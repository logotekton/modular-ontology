# ACadSharp DXF Evidence 06

Entity-level ACadSharp DXF evidence. TEXT, MTEXT, DIMENSION, INSERT, and HATCH are nodeized; low-information geometry is aggregated by layer.

## Counts

- Nodes: 2800
- Edges: 8400
- Chunks: 2800
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
