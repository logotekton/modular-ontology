# Source Registry

- Phase 2 source run: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\analysis\drawing_representation_port\runs\20260710-1420-p23`
- Read-only SHIP suite: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\온톨로지팩\여주\건축\revit-yeoju-architecture-acadsharp-schema-0_8_4-20260710_092149-rebuild-20260710_102852`
- Document key: `여주모듈러간부숙소신축공사_ythongMPXL7-ce7740d4af12054e`
- Source schema: `0.8.4`

## Files

- `drawing_phase2_element_topology_groups.jsonl`: 43294628 bytes, sha256 `905ab159b9a2d872a71339e0afcd92781af78860c19a1b2cbaea25b520099c8d`
- `drawing_phase2_element_topology_group_members.jsonl`: 90784119 bytes, sha256 `6a04420777795f582f7ad7caab797bed9c9199d88b13c57a09c047f9eb9a90da`
- `drawing_phase2_element_topology_group_manifest.json`: 4902 bytes, sha256 `061b0a96d66becfe35bcf7366ff754db9f8b822159157588ce67c98210ab3a8f`
