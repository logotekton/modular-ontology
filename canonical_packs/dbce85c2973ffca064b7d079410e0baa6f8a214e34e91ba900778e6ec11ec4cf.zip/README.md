# Revit Relationships 09

Original Revit graph_edges.jsonl relationships. Endpoint references are deduped suite-wide so canonical nodes are emitted once.

## Counts

- Nodes: 0
- Edges: 12000
- Chunks: 12000
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
