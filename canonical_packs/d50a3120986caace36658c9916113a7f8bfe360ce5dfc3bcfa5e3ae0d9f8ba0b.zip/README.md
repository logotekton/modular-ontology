# Revit Quantity Aggregates

Precomputed material, category, level, and material-family quantity aggregates for immediate takeoff answers.

## Counts

- Nodes: 240
- Edges: 14
- Chunks: 239
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
## Aggregate Scope

QuantityAggregate rows expose `properties.aggregate_scope` and `properties.aggregate_source_scope` so consumers do not mix element-primary and material takeoff totals.

- `aggregate_source_scope: element_primary` is independently deduplicated by `dedup_group_key` at highest `dedup_precedence` and is the source of generic `category_total` rows.
- `aggregate_source_scope: material` is sourced only from material takeoff facts and remains a separate row family.
- `aggregate_scope: total` is a rollup row such as an element category, material category, or material-family total.
- `aggregate_scope: by_material` is a material breakdown row and should be summed separately from total rows.
- `aggregate_group` identifies the rollup dimension (`category_total`, `material_category_total`, `material_family_total`, or `category_level_material`).
