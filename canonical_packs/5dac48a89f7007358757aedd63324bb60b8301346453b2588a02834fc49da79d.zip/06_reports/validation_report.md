# Validation Report

- Row shape: PASS
- Local duplicate IDs/triples: PASS
- External SHIP endpoint resolution: PASS (1604 unique endpoints)
- OpenCrab Cloud Pack required files: PASS
