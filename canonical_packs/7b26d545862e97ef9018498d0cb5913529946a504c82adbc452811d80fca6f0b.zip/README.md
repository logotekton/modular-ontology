# Revit Quantity Facts 07

Quantity fact shard from Revit parameter quantities and material takeoff quantities.

## Counts

- Nodes: 5000
- Edges: 6084
- Chunks: 5000
- Source schema: 0.8.4
- Raw export: `D:\02.AI 코딩\24.공모전\01.스마트건설챌린지\temp\revit_0_8_4_fix_round_20260710_102547_source_20260710_092149`
